from scrapy import cmdline

# cmdline.execute(["scrapy","crawl","yingyuan","-o","yingyuan.xml"])
# cmdline.execute(["scrapy","crawl","yingyuan","-o","yingyuan.json"])
# cmdline.execute(["scrapy","crawl","yingyuan","-o","yingyuan.csv"])

cmdline.execute(["scrapy","crawl","yingyuan"])
