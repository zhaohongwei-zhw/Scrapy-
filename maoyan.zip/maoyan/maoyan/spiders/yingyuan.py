# -*- coding: utf-8 -*-
import scrapy
from maoyan.items import CinemaItem


class YingyuanSpider(scrapy.Spider):
    name = 'yingyuan'
    allowed_domains = ['maoyan.com']
    start_urls = ['https://maoyan.com/cinemas?offset=0']

    def parse(self, response):
        hrefs = response.xpath("//div[@class='cinema-cell']//a[@class='cinema-name']/@href").getall()
        hrefs = [ "https://maoyan.com"+i for i in hrefs]

        for href in hrefs:
            #构造详情页的Request对象
            yield scrapy.Request(href,callback=self.parse_data)

        #请求下一页地址
        next_url = response.xpath("//div[@class='cinema-pager']/ul//a/@href").getall()[-1]
        if next_url and next_url!="javascript:void(0);" :
            next_url = "https://maoyan.com/cinemas"+next_url
            print(next_url)
            yield scrapy.Request(next_url,callback=self.parse)

    #解析详情页
    def parse_data(self,response):

        item = CinemaItem()
        #电影院名
        item["cinema_name"] = response.xpath("/html/body/div[3]/div/div[2]/div/h3/text()").get()
        #电影院地址
        item["cinema_addr"] = response.xpath("/html/body/div[3]/div/div[2]/div/div[1]/text()").get()
        #电影院电话
        item["cinema_phone"] = response.xpath("/html/body/div[3]/div/div[2]/div/div[2]/text()").get().replace('电话：',"")
        #近期上映的电影
        item["file"] = response.xpath("//div[@id='app']//h3/text()").getall()

        yield item