# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html


class MaoyanPipeline(object):
    def process_item(self, item, spider):
        print(dict(item))
        return item


# #数据库存储 测试成功
# from pymongo import MongoClient
# class MongoPipeline(object):
#
#     def open_spider(self,spider):
#         self.client = MongoClient(host="127.0.0.1",port=27017)
#         self.collection = self.client["maoyan"]["yingyuan"]
#
#     def close_spider(self,spider):
#         self.client.close()
#
#     def process_item(self, item, spider):
#         self.collection.insert_one(dict(item))
#         return item


